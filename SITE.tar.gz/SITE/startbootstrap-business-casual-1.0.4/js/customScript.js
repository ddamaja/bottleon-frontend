function paraf(tekst){
	tekst = "ovo je test paragraf;"
}